
%% ======================================================================== 
%           Feature selection based on whale optimization algorithm 
%                       for diseases diagnosis  
%                Hoda Zamani, Mohammad-Hossein Nadimi-Shahraki

%        International Journal of Computer Science and Information Security
%                   (IJCSIS),Vol. 14, No. 9, September 2016
%            -----------------------------------------------------------
%                    Source codes developed in MATLAB R2016b 
%                                Programmers:                                   
%                 Hoda Zamani, Mohammad-Hossein Nadimi-Shahraki 
%                E-Mail: zamanie_hoda@ymail.com,nadimi@ieee.org                    
%           -----------------------------------------------------------                                                             
%  Homepage: https://scholar.google.com/citations?user=sT0YnDIAAAAJ&hl=en 
%  Homepage: https://scholar.google.com/citations?user=bpZOZWsAAAAJ&hl=en
% ======================================================================== 


function FitnessValue = AccSz(x)
global DataSet trn vald SzW
SzW = 0.01;
x = x>0.5;
x = cat(2,x,zeros(size(x,1),1));
x = logical(x);

if sum(x)==0
    FitnessValue = inf;
    return;
end
classify = knnclassify(DataSet(vald,x),DataSet(trn,x),DataSet(trn,end));
cp = classperf(DataSet(vald,end),classify);
FitnessValue=(1-SzW)*(1-cp.CorrectRate)+SzW*sum(x)/(length(x)-1);
end